public interface IOperacao {

    int Operacao( int a, int b);

}
